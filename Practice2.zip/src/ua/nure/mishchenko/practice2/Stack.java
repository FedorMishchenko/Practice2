package ua.nure.mishchenko.practice2;

public interface Stack extends Container {

    void push(Object element);

    Object pop();

    Object top();
}
